
from typing import List
import log
from datamodel import Expression, Pair, Nil, Number, Undefined, NilType, Promise
from environment import global_attr
from evaluate_apply import Frame
from helper import pair_to_list, make_list, verify_exact_callable_length
from primitives import SingleOperandPrimitive, BuiltIn
from scheme_exceptions import OperandDeduceError, IrreversibleOperationError


@global_attr('append')
class Append(BuiltIn):

    def execute_evaluated(self, operands: List[Expression], frame: Frame) -> Expression:
        if (len(operands) == 0):
            return Nil
        exprs = []
        for operand in operands[:(- 1)]:
            if ((not isinstance(operand, Pair)) and (operand is not Nil)):
                raise OperandDeduceError(
                    ''.join(['Expected operand to be valid list, not ', '{}'.format(operand)]))
            exprs.extend(pair_to_list(operand))
        out = operands[(- 1)]
        for expr in reversed(exprs):
            out = Pair(expr, out)
        return out


@global_attr('car')
class Car(SingleOperandPrimitive):

    def execute_simple(self, operand: Expression) -> Expression:
        if isinstance(operand, Pair):
            return operand.first
        else:
            raise OperandDeduceError(''.join(
                ['Unable to extract first element, as ', '{}'.format(operand), ' is not a Pair.']))


@global_attr('cdr')
class Cdr(SingleOperandPrimitive):

    def execute_simple(self, operand: Expression) -> Expression:
        if isinstance(operand, Pair):
            return operand.rest
        else:
            raise OperandDeduceError(''.join(
                ['Unable to extract second element, as ', '{}'.format(operand), ' is not a Pair.']))


@global_attr('cons')
class Cons(BuiltIn):

    def execute_evaluated(self, operands: List[Expression], frame: Frame) -> Expression:
        verify_exact_callable_length(self, 2, len(operands))
        return Pair(operands[0], operands[1])


@global_attr('length')
class Length(SingleOperandPrimitive):

    def execute_simple(self, operand: Expression) -> Expression:
        if ((not isinstance(operand, Pair)) and (operand is not Nil)):
            raise OperandDeduceError(''.join(
                ['Unable to calculate length, as ', '{}'.format(operand), ' is not a valid list.']))
        return Number(len(pair_to_list(operand)))


@global_attr('list')
class MakeList(BuiltIn):

    def execute_evaluated(self, operands: List[Expression], frame: Frame) -> Expression:
        return make_list(operands)


@global_attr('set-car!')
class SetCar(BuiltIn):

    def execute_evaluated(self, operands: List[Expression], frame: Frame) -> Expression:
        verify_exact_callable_length(self, 2, len(operands))
        if log.logger.fragile:
            raise IrreversibleOperationError()
        (pair, val) = operands
        if (not isinstance(pair, Pair)):
            raise OperandDeduceError(
                ''.join(['set-car! expected a Pair, received ', '{}'.format(pair), '.']))
        pair.first = val
        log.logger.raw_out(
            'WARNING: Mutation operations on pairs are not yet supported by the debugger.')
        return Undefined


@global_attr('set-cdr!')
class SetCdr(BuiltIn):

    def execute_evaluated(self, operands: List[Expression], frame: Frame) -> Expression:
        verify_exact_callable_length(self, 2, len(operands))
        if log.logger.fragile:
            raise IrreversibleOperationError()
        (pair, val) = operands
        if (not isinstance(pair, Pair)):
            raise OperandDeduceError(
                ''.join(['set-cdr! expected a Pair, received ', '{}'.format(pair), '.']))
        if (not isinstance(val, (Pair, Promise, NilType))):
            raise OperandDeduceError(''.join(['Unable to assign ', '{}'.format(
                val), ' to cdr, expected a Pair, Nil, or Promise.']))
        pair.rest = val
        log.logger.raw_out(
            'WARNING: Mutation operations on pairs are not yet supported by the debugger.')
        return Undefined
